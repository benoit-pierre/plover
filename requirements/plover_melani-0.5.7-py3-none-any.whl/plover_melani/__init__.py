#!/usr/bin/env python

DICTIONARIES = (
    ('Melani (orthography).py', 'dictionary.py'),
)

