# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'plover_config_wiz/machine.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MachinePage(object):
    def setupUi(self, MachinePage):
        MachinePage.setObjectName("MachinePage")
        MachinePage.resize(400, 300)
        MachinePage.setWindowTitle("")
        self.gridLayout = QtWidgets.QGridLayout(MachinePage)
        self.gridLayout.setObjectName("gridLayout")
        self.machine = QtWidgets.QComboBox(MachinePage)
        self.machine.setIconSize(QtCore.QSize(256, 128))
        self.machine.setObjectName("machine")
        self.gridLayout.addWidget(self.machine, 1, 0, 1, 1)
        self.label = QtWidgets.QLabel(MachinePage)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)

        self.retranslateUi(MachinePage)
        QtCore.QMetaObject.connectSlotsByName(MachinePage)

    def retranslateUi(self, MachinePage):
        _translate = QtCore.QCoreApplication.translate
        MachinePage.setTitle(_translate("MachinePage", "Machine"))
        self.label.setText(_translate("MachinePage", "This wizard will help you setup your machine for use with Plover.\n"
"\n"
"Please select the type of machine you would like to use:"))

