
from PyQt5.QtWidgets import QWizardPage

from plover_config_wiz.detect_serial_port_ui import Ui_DetectSerialPortPage
from plover_config_wiz.serial_port import scan


class DetectSerialPortPage(QWizardPage, Ui_DetectSerialPortPage):

    def __init__(self):
        super(DetectSerialPortPage, self).__init__()
        self.setupUi(self)
        self.step = 'startup'
        self.ports = []
        self.serial_port = None

    def _update_label(self):
        if self.step == 'startup':
            text = (
                'Please make sure the machine is <b>disconnected</b>, '
                'and click the "Next" button.'
            )
        elif self.step == 'detect':
            text = (
                'Please make sure the machine is <b>connected</b>, '
                'and click the "Next" button.'
            )
        elif self.step == 'failed':
            text = (
                'Auto-detection failed!'
            )
        else:
            raise ValueError(self.step)
        self.label.setText(text)

    def initializePage(self):
        self.step = 'startup'
        self._update_label()

    def validatePage(self):
        ports = scan()
        wizard = self.wizard()
        if self.step == 'startup':
            self.ports = ports
            self.step = 'detect'
        elif self.step == 'detect':
            new_ports = list(sorted(set(ports) - set(self.ports)))
            if new_ports:
                wizard.config['machine_specific_options']['port'] = new_ports[0]
                return True
            self.step = 'failed'
        elif self.step == 'failed':
            return False
        else:
            raise ValueError(self.step)
        self._update_label()
        return False

    def nextId(self):
        wizard = self.wizard()
        if self.step in ('failed', 'startup'):
            return wizard.detect_serial_port_page
        if self.step == 'detect':
            return wizard.test_page
        raise ValueError(self.step)
