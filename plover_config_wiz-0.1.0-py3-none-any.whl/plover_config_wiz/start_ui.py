# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'plover_config_wiz/start.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_StartPage(object):
    def setupUi(self, StartPage):
        StartPage.setObjectName("StartPage")
        StartPage.resize(400, 300)
        StartPage.setWindowTitle("")
        self.gridLayout = QtWidgets.QGridLayout(StartPage)
        self.gridLayout.setObjectName("gridLayout")
        self.machine = QtWidgets.QComboBox(StartPage)
        self.machine.setIconSize(QtCore.QSize(256, 128))
        self.machine.setObjectName("machine")
        self.gridLayout.addWidget(self.machine, 1, 0, 1, 1)
        self.label = QtWidgets.QLabel(StartPage)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)

        self.retranslateUi(StartPage)
        QtCore.QMetaObject.connectSlotsByName(StartPage)

    def retranslateUi(self, StartPage):
        _translate = QtCore.QCoreApplication.translate
        StartPage.setTitle(_translate("StartPage", "Machine"))
        self.label.setText(_translate("StartPage", "This wizard will help you setup your machine for use with Plover.\n"
"\n"
"Please select the type of machine you would like to use:"))

