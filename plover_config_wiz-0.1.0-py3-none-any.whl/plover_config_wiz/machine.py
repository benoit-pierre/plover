
import ast
import re

from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QWizardPage

from .machine_ui import Ui_MachinePage
from . import resource_filename


class MachinePage(QWizardPage, Ui_MachinePage):

    MACHINES = [
        re.split(r'\t+', line.strip()) for line in
        # name icon next_page config
        '''

        Keyboard			keyboard.jpg			keyboard		'machine_type': 'Keyboard'
        Infinity Ergonomic	infinity_ergonomic.png	serial_port		'machine_type': 'Gemini PR', 'machine_specific_options': {'baudrate': 115200}
        Lightspeed			lightspeed.jpg			serial_port		'machine_type': 'TX Bolt', 'machine_specific_options': {'baudrate': 9600}
        Procat Flash		procat_flash.jpg		procat_flash	'machine_type': 'TX Bolt'
        SOFT/HRUF			soft_hruf.png			soft_hruf		'machine_type': 'Keyboard'
        Stenomod			stenomod.jpg			serial_port		'machine_type': 'TX Bolt'
        Stentura			stentura.jpg			stentura		'machine_type': 'Stentura'
        Treal				treal.jpg				test			'machine_type': 'Treal'

        '''.strip().split('\n')
    ]

    def __init__(self):
        super(MachinePage, self).__init__()
        self.setupUi(self)
        self._config = {}
        self._next_page = {}
        for name, icon, next_page, config in self.MACHINES:
            self.machine.addItem(QIcon(resource_filename(icon)), name)
            self._config[name] = ast.literal_eval('{' + config + '}')
            self._next_page[name] = next_page

    def validatePage(self):
        wizard = self.wizard()
        machine = self.machine.currentText()
        wizard.machine = machine
        wizard.config.update(self._config[machine])
        return True

    def nextId(self):
        wizard = self.wizard()
        machine = self.machine.currentText()
        return wizard._page_id[self._next_page[machine]]
