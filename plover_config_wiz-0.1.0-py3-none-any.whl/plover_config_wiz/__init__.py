
import pkg_resources


def resource_filename(name):
    return pkg_resources.resource_filename(__name__, 'resources/' + name)

def resource_string(name):
    return pkg_resources.resource_string(__name__, 'resources/' + name)
