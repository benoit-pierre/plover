# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'plover_config_wiz/test.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_TestPage(object):
    def setupUi(self, TestPage):
        TestPage.setObjectName("TestPage")
        TestPage.resize(400, 300)
        self.verticalLayout = QtWidgets.QVBoxLayout(TestPage)
        self.verticalLayout.setObjectName("verticalLayout")
        self.results = QtWidgets.QLabel(TestPage)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.MinimumExpanding, QtWidgets.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.results.sizePolicy().hasHeightForWidth())
        self.results.setSizePolicy(sizePolicy)
        self.results.setText("")
        self.results.setObjectName("results")
        self.verticalLayout.addWidget(self.results)
        self.label_2 = QtWidgets.QLabel(TestPage)
        self.label_2.setWordWrap(True)
        self.label_2.setObjectName("label_2")
        self.verticalLayout.addWidget(self.label_2)
        self.strokes = QtWidgets.QPlainTextEdit(TestPage)
        self.strokes.setReadOnly(True)
        self.strokes.setObjectName("strokes")
        self.verticalLayout.addWidget(self.strokes)
        self.label = QtWidgets.QLabel(TestPage)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)

        self.retranslateUi(TestPage)
        QtCore.QMetaObject.connectSlotsByName(TestPage)

    def retranslateUi(self, TestPage):
        _translate = QtCore.QCoreApplication.translate
        TestPage.setWindowTitle(_translate("TestPage", "WizardPage"))
        TestPage.setTitle(_translate("TestPage", "Testing"))
        self.label_2.setText(_translate("TestPage", "You can test you configuration by pressing some keys and checking the output below:"))
        self.label.setText(_translate("TestPage", "Click the \"Finish\" button to save your configuration and start using Plover."))

