# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'plover_config_wiz/final.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_FinalPage(object):
    def setupUi(self, FinalPage):
        FinalPage.setObjectName("FinalPage")
        FinalPage.resize(400, 300)
        self.verticalLayout = QtWidgets.QVBoxLayout(FinalPage)
        self.verticalLayout.setObjectName("verticalLayout")
        self.results = QtWidgets.QLabel(FinalPage)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.MinimumExpanding, QtWidgets.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.results.sizePolicy().hasHeightForWidth())
        self.results.setSizePolicy(sizePolicy)
        self.results.setText("")
        self.results.setObjectName("results")
        self.verticalLayout.addWidget(self.results)
        self.label = QtWidgets.QLabel(FinalPage)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)

        self.retranslateUi(FinalPage)
        QtCore.QMetaObject.connectSlotsByName(FinalPage)

    def retranslateUi(self, FinalPage):
        _translate = QtCore.QCoreApplication.translate
        FinalPage.setWindowTitle(_translate("FinalPage", "WizardPage"))
        FinalPage.setTitle(_translate("FinalPage", "Congratulations!"))
        self.label.setText(_translate("FinalPage", "Click the \"Finish\" button to save your configuration and start using Plover."))

