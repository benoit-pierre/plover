# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'plover_config_wiz/soft_hruf.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_SoftHrufPage(object):
    def setupUi(self, SoftHrufPage):
        SoftHrufPage.setObjectName("SoftHrufPage")
        SoftHrufPage.resize(400, 300)
        self.gridLayout = QtWidgets.QGridLayout(SoftHrufPage)
        self.gridLayout.setObjectName("gridLayout")
        self.info = MarkdownWidget(SoftHrufPage)
        self.info.setSource(QtCore.QUrl("resource:soft_hruf"))
        self.info.setObjectName("info")
        self.gridLayout.addWidget(self.info, 0, 0, 1, 1)

        self.retranslateUi(SoftHrufPage)
        QtCore.QMetaObject.connectSlotsByName(SoftHrufPage)

    def retranslateUi(self, SoftHrufPage):
        _translate = QtCore.QCoreApplication.translate
        SoftHrufPage.setWindowTitle(_translate("SoftHrufPage", "WizardPage"))
        SoftHrufPage.setTitle(_translate("SoftHrufPage", "SOFT/HRUF"))

from plover_config_wiz.markdown_widget import MarkdownWidget
