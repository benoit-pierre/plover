# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'plover_config_wiz/serial_port.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_SerialPortPage(object):
    def setupUi(self, SerialPortPage):
        SerialPortPage.setObjectName("SerialPortPage")
        SerialPortPage.resize(400, 300)
        self.gridLayout = QtWidgets.QGridLayout(SerialPortPage)
        self.gridLayout.setObjectName("gridLayout")
        self.serial_port = QtWidgets.QComboBox(SerialPortPage)
        self.serial_port.setObjectName("serial_port")
        self.serial_port.addItem("")
        self.gridLayout.addWidget(self.serial_port, 1, 0, 1, 1)
        self.label = QtWidgets.QLabel(SerialPortPage)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)

        self.retranslateUi(SerialPortPage)
        QtCore.QMetaObject.connectSlotsByName(SerialPortPage)

    def retranslateUi(self, SerialPortPage):
        _translate = QtCore.QCoreApplication.translate
        SerialPortPage.setWindowTitle(_translate("SerialPortPage", "WizardPage"))
        SerialPortPage.setTitle(_translate("SerialPortPage", "Serial Port"))
        self.serial_port.setItemText(0, _translate("SerialPortPage", "Auto-detect"))
        self.label.setText(_translate("SerialPortPage", "Please select the serial port to use. If you\'re not sure, select \"Auto-detect\" and this wizard will attempt to automatically detect the correct port."))

