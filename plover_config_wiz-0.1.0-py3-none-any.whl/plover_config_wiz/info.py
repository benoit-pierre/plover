
from PyQt5.QtCore import QUrl
from PyQt5.QtWidgets import QWizardPage

from plover_config_wiz.info_ui import Ui_InfoPage


class InfoPage(QWizardPage, Ui_InfoPage):

    def __init__(self):
        super(InfoPage, self).__init__()
        self.setupUi(self)
        self.resource = None

    def initializePage(self):
        self.info.setSource(QUrl('resource:' + self.resource))
