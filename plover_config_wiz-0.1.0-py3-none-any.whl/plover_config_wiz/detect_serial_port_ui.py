# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'plover_config_wiz/detect_serial_port.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_DetectSerialPortPage(object):
    def setupUi(self, DetectSerialPortPage):
        DetectSerialPortPage.setObjectName("DetectSerialPortPage")
        DetectSerialPortPage.resize(400, 300)
        self.gridLayout = QtWidgets.QGridLayout(DetectSerialPortPage)
        self.gridLayout.setObjectName("gridLayout")
        self.label = QtWidgets.QLabel(DetectSerialPortPage)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy)
        self.label.setText("")
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)

        self.retranslateUi(DetectSerialPortPage)
        QtCore.QMetaObject.connectSlotsByName(DetectSerialPortPage)

    def retranslateUi(self, DetectSerialPortPage):
        _translate = QtCore.QCoreApplication.translate
        DetectSerialPortPage.setWindowTitle(_translate("DetectSerialPortPage", "DetectSerialPortPage"))
        DetectSerialPortPage.setTitle(_translate("DetectSerialPortPage", "Serial Port Auto-Detection"))

