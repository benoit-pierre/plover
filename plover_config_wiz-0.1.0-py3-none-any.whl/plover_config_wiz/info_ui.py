# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'plover_config_wiz/info.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_InfoPage(object):
    def setupUi(self, InfoPage):
        InfoPage.setObjectName("InfoPage")
        InfoPage.resize(400, 300)
        self.gridLayout = QtWidgets.QGridLayout(InfoPage)
        self.gridLayout.setObjectName("gridLayout")
        self.info = MarkdownWidget(InfoPage)
        self.info.setObjectName("info")
        self.gridLayout.addWidget(self.info, 0, 0, 1, 1)

        self.retranslateUi(InfoPage)
        QtCore.QMetaObject.connectSlotsByName(InfoPage)

    def retranslateUi(self, InfoPage):
        _translate = QtCore.QCoreApplication.translate
        InfoPage.setWindowTitle(_translate("InfoPage", "WizardPage"))

from plover_config_wiz.markdown_widget import MarkdownWidget
