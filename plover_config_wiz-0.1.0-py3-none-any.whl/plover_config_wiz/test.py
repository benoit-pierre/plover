
from html import escape

from PyQt5.QtWidgets import QWizardPage

from .test_ui import Ui_TestPage


class TestPage(QWizardPage, Ui_TestPage):

    def __init__(self):
        super(TestPage, self).__init__()
        self.setupUi(self)
        self._initial_config = {}

    def initializePage(self):
        wizard = self.wizard()
        machine = escape(wizard.config['machine_type'])
        text = '<b>Configuration:</b><ul>'
        text += '<li><b>machine type:</b> %s</li>' % machine
        options = wizard.config['machine_specific_options']
        if options:
            text += '</br><li><b>options:</b><ul>'
            for name, value in sorted(options.items()):
                text += '<li>%s: %s' % (escape(name), escape(str(value)))
            text += '</ul></li>'
        text += '</ul>'
        self.results.setText(text)
        if self._initial_config:
            return
        engine = wizard._engine
        with engine:
            config = engine.config
            self._initial_config = dict(
                machine_type=config['machine_type'],
                machine_specific_options=config['machine_specific_options'],
            )
            engine.set_output(False)
            engine.config = wizard.config
            engine.signal_connect('stroked', self.on_stroke)
        self.strokes.clear()

    def cleanupPage(self):
        wizard = self.wizard()
        engine = wizard._engine
        with engine:
            engine.signal_disconnect('stroked', self.on_stroke)
            engine.config = self._initial_config
        self._initial_config = {}

    def on_stroke(self, stroke):
        self.strokes.appendPlainText(stroke.rtfcre)
