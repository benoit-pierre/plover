
import os.path

from markdown import markdown

from PyQt5.QtWidgets import QTextBrowser

from . import resource_filename, resource_string


MARKDOWN_CSS = 'file://%s' % resource_filename('styles.css').replace(os.path.sep, '/')

def markdown_to_html(md_string):
    return (
        '<html><head>' +
        '<link rel="stylesheet" type="text/css" href="'+ MARKDOWN_CSS + '">' +
        '</head>' + markdown(md_string, extensions=[
            'markdown.extensions.codehilite',
            'markdown.extensions.fenced_code',
        ], output_format='xhtml5') +
        '</html>'
    )


class MarkdownWidget(QTextBrowser):

    def __init__(self, parent=None):
        super(MarkdownWidget, self).__init__(parent)
        self.setOpenExternalLinks(True)
        self.setOpenLinks(True)

    def setSource(self, url):
        assert url.scheme() in 'resource'
        md_string = resource_string(url.path() + '.md').decode('utf-8')
        html = markdown_to_html(md_string)
        self.setHtml(html)
