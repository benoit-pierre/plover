TODO:

-   help explaining the 2 options
-   combo box with options: NKRO (default), TX Bolt
