The Procat Flash must be configured to use the TX Bolt protocol:

- press **Mode** (far right button)
- click **Setup**
- then press the **Emul** button, the display should now read:
```
Emulate: Baron
```
