TODO:

- help explaining different options
- combo box with options: NKRO (default), arpeggiate, and QMK variants for
  emulating other machines (TX Bolt, Gemini PR, MIDI, \...)
