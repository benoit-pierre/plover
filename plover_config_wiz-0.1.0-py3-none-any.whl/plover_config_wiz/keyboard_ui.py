# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'plover_config_wiz/keyboard.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_KeyboardPage(object):
    def setupUi(self, KeyboardPage):
        KeyboardPage.setObjectName("KeyboardPage")
        KeyboardPage.resize(400, 300)
        self.gridLayout = QtWidgets.QGridLayout(KeyboardPage)
        self.gridLayout.setObjectName("gridLayout")
        self.textBrowser = MarkdownWidget(KeyboardPage)
        self.textBrowser.setSource(QtCore.QUrl("resource:keyboard"))
        self.textBrowser.setObjectName("textBrowser")
        self.gridLayout.addWidget(self.textBrowser, 0, 0, 1, 1)

        self.retranslateUi(KeyboardPage)
        QtCore.QMetaObject.connectSlotsByName(KeyboardPage)

    def retranslateUi(self, KeyboardPage):
        _translate = QtCore.QCoreApplication.translate
        KeyboardPage.setWindowTitle(_translate("KeyboardPage", "WizardPage"))
        KeyboardPage.setTitle(_translate("KeyboardPage", "Keyboard"))

from plover_config_wiz.markdown_widget import MarkdownWidget
