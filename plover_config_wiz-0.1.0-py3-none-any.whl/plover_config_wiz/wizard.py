
from importlib import import_module

from PyQt5.QtWidgets import QComboBox, QWizard, QWizardPage

from plover.gui_qt.tool import Tool

from . import resource_filename


class ConfigWiz(QWizard, Tool):

    TITLE = 'Config Wiz'
    ROLE = 'config_wiz'
    ICON = resource_filename('icon.svg')

    PAGES = [
        line.strip().split() for line in '''

        machine py

        keyboard ui test
        soft_hruf ui test
        stentura rst serial_port
        procat_flash rst serial_port

        serial_port py
        detect_serial_port py

        test py

        '''.strip().split('\n')

        if line.strip()
    ]

    def __init__(self, engine):
        super(ConfigWiz, self).__init__(engine)
        self._engine = engine
        self._page_name = {-1: ''}
        self._page_id = {}
        self._next_page = {}
        for page_params in self.PAGES:
            page_name, page_type, *page_params = page_params
            page_title = page_name.replace('_', ' ').title()
            page_module_name = '.%s' % page_name
            page_class_name = '%sPage' % page_title.replace(' ', '')
            page_package = 'plover_config_wiz'
            if page_type == 'py':
                page_module = import_module(page_module_name, page_package)
                page_class = getattr(page_module, page_class_name)
                page = page_class()
            elif page_type == 'ui':
                page_module = import_module('%s_ui' % page_module_name, page_package)
                page_ui = getattr(page_module, 'Ui_%s' % page_class_name)
                page = QWizardPage()
                page_ui().setupUi(page)
            else:
                page_module = import_module('.info', page_package)
                page_class = getattr(page_module, 'InfoPage')
                page = page_class()
                page.resource = page_name
            page_id = self.addPage(page)
            setattr(self, '%s_page' % page_name, page_id)
            self._page_name[page_id] = page_name
            self._page_id[page_name] = page_id
            if page_params:
                assert len(page_params) == 1
                next_page, = page_params
                self._next_page[page_id] = next_page
        self.machine = None
        self.config = {
            'machine_specific_options': {}
        }
        self.currentIdChanged.connect(self.on_id_changed)

    def nextId(self):
        page_id = self.currentId()
        page = self.currentPage()
        if page_id in self._next_page:
            next_page = self._next_page[page_id]
            page_id = self._page_id[next_page]
        else:
            page_id = super(ConfigWiz, self).nextId()
        # print(self._page_name[self.currentId()], '->', self._page_name[page_id])
        return page_id

    def on_id_changed(self, page_id):
        self.initializePage(page_id)
