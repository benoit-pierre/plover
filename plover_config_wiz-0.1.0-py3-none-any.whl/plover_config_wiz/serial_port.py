
from serial.tools.list_ports import comports

from PyQt5.QtWidgets import QWizardPage

from plover_config_wiz.serial_port_ui import Ui_SerialPortPage


if False:
    # For debugging purpose.
    def scan():
        return sorted(
            line.strip()
            for line in open('comports.txt')
        )
else:
    def scan():
        return sorted(x[0] for x in comports())


class SerialPortPage(QWizardPage, Ui_SerialPortPage):

    def __init__(self):
        super(SerialPortPage, self).__init__()
        self.setupUi(self)

    def initializePage(self):
        auto_detect = self.serial_port.itemText(0)
        serial_port = self.serial_port.currentText()
        ports = [auto_detect] + list(scan())
        self.serial_port.clear()
        self.serial_port.addItems(ports)
        if serial_port in ports:
            index = ports.index(serial_port)
        else:
            index = 0
        self.serial_port.setCurrentIndex(index)

    def validatePage(self):
        wizard = self.wizard()
        serial_port = self.serial_port.currentText()
        if serial_port != 'Auto-detect':
            wizard.config['machine_specific_options']['port'] = serial_port
        return True

    def nextId(self):
        wizard = self.wizard()
        serial_port = self.serial_port.currentText()
        if serial_port == 'Auto-detect':
            return wizard.detect_serial_port_page
        return wizard.test_page
