Plover Config Wiz
=================

Icon made by `Smashicons <https://www.flaticon.com/authors/smashicons/>`_ from `www.flaticon.com <http://www.flaticon.com/>`_.


